
#ifndef INTERFAZ_H
#define INTERFAZ_H

class Interfaz {
public:
    void menu();
};

#endif
