
#include "Interfaz.h"

int main() {
    Interfaz interfaz;
    interfaz.menu();
    return 0;
}
